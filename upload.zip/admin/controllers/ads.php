<?php
$task = get('task', 'noop', $_REQUEST);
$apply = get('apply', false, $_REQUEST);
$error = false;

switch($task){
	case 'save':
		$banner = get('banner', array(), $_POST);
		$banners = get_model( 'banner' );
		if ( !isset($banner['id']) || empty($banner['id']) ){
			$max_id = 0;
			if ( count($banners) ){
				foreach ($banners as $i => $current){
					if ($max_id < $current['id']){
						$max_id = $current['id'];
					}
				}
			}
			$banner['id'] 				= $max_id + 1;
			$banner['title'] 			= filter_var($banner['title'], FILTER_SANITIZE_STRING);
			$banner['content']			= $banner['content'];
			
			if ( empty($banner['title']) ){
				push_message('Page Title should not be empty!');
				$error = true;
			}
			
			// add to model
			$banners[$banner['id']] = $banner;
			
			save_model($banners, 'banner');
			push_message('Ads saved!');
			if ( $apply !== false ){
				header('Location: index.php?view=ads&id='.$banner['id']);
				exit;
			}
		} else {
			// update.
			foreach ($banners as $i => $current){
				if ( $banner['id'] == $current['id'] ){
					
					if ( empty($banner['title']) ){
						push_message('Page Title should not be empty!', 'danger');
						$error = true;
					}

					$banners[$i]['title'] = filter_var($banner['title'], FILTER_SANITIZE_STRING);
					$banners[$i]['content'] = ($banner['content']);
					
					if ( !$error ){
						save_model($banners, 'banner');
						push_message('Ads updated!');
					} else {
						$apply = true;
					}
									
					break;
				}
			}
			
		}
		break;
	case 'update':
		$delete_id = get('delete', 0, $_POST);
		if ( $delete_id ){
			$banners = get_model( 'banner' );
			foreach($banners as $i => $p){
				if ( $delete_id == $p['id'] ){
					$apply = true;
					unset($banners[$i]);
					save_model($banners, 'banner');
					push_message('Ads was deleted!');
					break;
				}
			}
		}
		break;
	default:
}

if ( $apply !== false ){
	header('Location: '.get_current_url());
	exit;
}
header('Location: index.php?view=ads');
exit;