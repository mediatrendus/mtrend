<?php
$id = get('id', '0', $_GET);
if ( $id ){
	$cat = get_categories($id);
	if ( $urls = get_feed_urls( $id ) ){
		global $simplepie_cache_location;
		if ( !isset($simplepie_cache_location) ){
			$simplepie_cache_location = ABS.'/cache';
		}
		foreach ($urls as $url){
			$cache_dir = $simplepie_cache_location . '/' . md5($url) . '/';
			if ( file_exists($cache_dir) ){
				delete_directory($cache_dir);
			}
		}
		if ( is_array($cat) ){
			$cat = array_shift($cat);
		}
		push_message( 'Clean cache for category <b>' . $cat['name'] .'</b>' );
	}
	header('Location: index.php?view=maintenance');
	exit;
}
header('Location: index.php?view=maintenance');
exit;