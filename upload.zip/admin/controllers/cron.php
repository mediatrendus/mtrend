<?php
if ( file_exists(ABS.'/cron.php') ){
	ob_start();
	require_once ABS.'/cron.php';
	$cron_msg = ob_get_clean();
	?>
	<div class="alert alert-info">
     	<?php echo $cron_msg; ?>
    </div>
    <?php
}
exit;