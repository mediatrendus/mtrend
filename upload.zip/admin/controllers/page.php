<?php
$task = get('task', 'noop', $_REQUEST);
$apply = get('apply', false, $_REQUEST);
$error = false;

switch($task){
	case 'save':
		$page = get('page', array(), $_POST);
		$pages = get_model( 'page' );
		
		if ( !isset($page['id']) || empty($page['id']) ){
			$max_id = 0;
			if (count($pages)){
				foreach ($pages as $i => $current){
					if ($max_id < $current['id']){
						$max_id = $current['id'];
					}
				}
			}
			$page['id'] 				= $max_id + 1;
			$page['title'] 				= filter_var($page['title'], FILTER_SANITIZE_STRING);
			if ( !isset($page['slug']) || empty($page['slug']) ){
				$page['slug'] = get_seoname( $page['title'] );
			} else {
				// make sure it is valid slug
				$page['slug'] = get_seoname( $page['slug'] );
			}
			$page['state']				= filter_var(@$page['state'], FILTER_SANITIZE_NUMBER_INT);
			$page['slug']				= filter_var($page['slug'], FILTER_SANITIZE_STRING);
			$page['parent']				= filter_var($page['parent'], FILTER_SANITIZE_NUMBER_INT);
			$page['allow_comment']		= filter_var(@$page['allow_comment'], FILTER_SANITIZE_NUMBER_INT);
			$page['content']			= $page['content'];
			$page['meta_keywords']		= filter_var($page['meta_keywords'], FILTER_SANITIZE_STRING);
			$page['meta_description']	= filter_var($page['meta_description'], FILTER_SANITIZE_STRING);
			
			$page['created_date'] = date('Y-m-d H:i:s');
			$page['modified_date'] = '0000-00-00 00:00:00';
			
			if ( empty($page['title']) ){
				push_message('Page Title should not be empty!');
				$error = true;
			}
			
			image_process($page, $_FILES);
			// add to model
			if ( is_numeric($page['ordering']) ){
				$_pages = array();
				$inserted = false;
				if ( count($pages) ){
					foreach ( $pages as $i => $p ){
						if ($page['ordering'] == $p['id'] && !$inserted){
							$_pages[$page['id']] = $page;
							$inserted = true;
						}
						$_pages[$i] = $pages[$i];
					}
				}
				
				$pages = $_pages;
			} else {
				$_pages = array();
				$inserted = false;
				$parent_id = get('parent', 0, $page);
				if ( count($pages) ){
					$last = null;
					$parent_ids = array();
					foreach ( $pages as $i => $p ){
						if ( in_array($p['parent'], $parent_ids) ){
							$last = $p['id'];
							array_push($parent_ids, $p['id']);
						}
					}
					
					if ( is_null($last) ){
						$last = $parent_id;
					}
					
					foreach ( $pages as $i => $p ){
						$_pages[$i] = $pages[$i];
						if ( $last == $p['id'] ){
							$inserted = true;
							$_pages[$page['id']] = $page;
						}
					}
				}
				if (!$inserted){
					$_pages[$page['id']] = $page;
				}
				$pages = $_pages;
			}
			
			if ( !$error ){
				save_model($pages, 'page');
				push_message('Page saved!');
			}
			
			if ( $apply !== false ){
				header('Location: index.php?view=pages&id='.$page['id']);
				exit;
			}
		} else {
			// update.
			$error = false;
			$tmp_pages = array();
			foreach ($pages as $i => $current){
				if ( $page['id'] == $current['id'] ){
					
					if ( empty($page['title']) ){
						push_message('Page Title should not be empty!', 'danger');
						$error = true;
					}

					if ( empty($page['slug']) ){
						$page['slug'] = get_seoname( $page['title'] );
						if ( $exists = get_page_by_seoname($page['slug']) ){
							if ( $exists['id'] != $page['id'] ){
								$page['slug'] .= '-2';
							}
						}
					} else if ( strcmp($page['slug'], $pages[$i]['slug']) ){
						$page['slug'] = get_seoname($page['slug']);
					}
					$page['state'] = filter_var(@$page['state'], FILTER_SANITIZE_NUMBER_INT);
					$page['title'] = filter_var($page['title'], FILTER_SANITIZE_STRING);
					$page['slug']  = filter_var($page['slug'], FILTER_SANITIZE_STRING);
					$page['parent']= filter_var($page['parent'], FILTER_SANITIZE_NUMBER_INT);
					$page['allow_comment'] = filter_var($page['allow_comment'], FILTER_SANITIZE_NUMBER_INT);
					$page['content'] = $page['content'];
					$page['meta_keywords'] = filter_var($page['meta_keywords'], FILTER_SANITIZE_STRING);
					$page['meta_description'] = filter_var($page['meta_description'], FILTER_SANITIZE_STRING);
					$page['created_date']  = filter_var($page['created_date'], FILTER_SANITIZE_STRING);
					
					$page['modified_date'] = date('Y-m-d H:i:s');
					if ( !isset( $page['created_date'] ) || empty($page['created_date']) ){
						$page['created_date'] = date('Y-m-d H:i:s');
					}
					
					image_process($page, $_FILES);
					$pages[$i] = $page;
					if ( !$error ){
						$tmp_pages[$pages[$i]['id']] = $pages[$i];
						$parent_ids = array( $pages[$i]['id'] );
						foreach ($pages as $j => $p ){
							if ( in_array($p['parent'], $parent_ids) ){
								$tmp_pages[ $p['id'] ] = $pages[$j];
								array_push($parent_ids, $p['id']);
							}
						}
						// save_model($pages, 'page');
						// push_message('Page updated!');
					} else {
						$apply = true;
					}
					
					break;
				}
			}
			
			// change order.
		
			if ( is_numeric($page['ordering']) ){
				$_pages = array();
				$inserted = false; $insertChild = false;
				if ( count($pages) ){
					foreach ( $pages as $i => $p ){
						if ($page['ordering'] == $p['id'] && !$inserted){
							$_pages[$page['id']] = $page;
							$inserted = true;
						}
						$_pages[$i] = $pages[$i];
					}
				}
			
				$pages = $_pages;
			} else {
				$_pages = array();
				$inserted = false;
				$parent_id = get('parent', 0, $page);
				if ( count($pages) ){
					$last = null;
					$parent_ids = array( $parent_id );
					foreach ( $pages as $i => $p ){
						if ( $page['id'] == $p['id'] ) continue;
						if ( $p['parent'] == $parent_id ){
							$last = $p['id'];
						}
					}
					if ( is_null($last) ){
						$last = $parent_id;
					} else {
						$last_match = false;
						$last_parents = array( $last );
						foreach ( $pages as $i => $p ){
							if ( $last_match && in_array($p['id'], $last_parents) ){
								$last = $pages[$i]['id'];
								array_push($last_parents, $p['id']);
							}
							if ( $last == $p['id'] ) {
								$last_match = true;
							}
						}
					}
					
					foreach ( $pages as $i => $p ){
						if ( isset( $tmp_pages[$p['id']] ) ) continue;
						$_pages[$i] = $pages[$i];
						if ( $last == $p['id'] ){
							$inserted = true;
							foreach ($tmp_pages as $k => $pp){
								$_pages[ $k ] = $tmp_pages[ $k ];
							}
						}
					}
				}
				if (!$inserted){
					foreach ($tmp_pages as $k => $pp){
						$_pages[ $k ] = $tmp_pages[ $k ];
					}
				}
				$pages = $_pages;
			}
			
			if ( !$error ){
				save_model($pages, 'page');
				push_message('Page saved!');
			}
			
		}
		break;
	case 'update':
		$delete_id = get('delete', 0, $_POST);
		if ( $delete_id ){
			$pages = get_model( 'page' );
			foreach($pages as $i => $p){
				if ( $delete_id == $p['id'] ){
					$apply = true;
					unset($pages[$i]);
					save_model($pages, 'page');
					push_message('Page was deleted!');
					break;
				}
			}
		}
		break;
	case 'getorders':
		$page_parent = get('parent', 0, $_POST);
		$page_ordering = get('ordering', 'last-child', $_POST);
		$ref_page_id = get('id', 0, $_POST);
		$pages = get_model('page');
		
		$order_select = ''; // <select id="page_ordering" name="page[ordering]" class="form-control">';
		$order_last_selected = true;
		foreach ( $pages as $i => $p ){
			if ( $p['parent'] != $page_parent ) continue;
			if ( $p['id'] == $ref_page_id ) continue;
			if ($page_ordering == $p['id'] ){
				$order_last_selected = false;
				$order_select .= '<option value="'.$p['id'].'" selected="selected">'. $p['title'] . '</option>';
			} else {
				$order_select .= '<option value="'.$p['id'].'">'. $p['title'] . '</option>';
			}
			
		}
		if ( $order_last_selected ){
			$order_select .= '<option value="last-child" selected="selected">Last</option>';
		} else {
			$order_select .= '<option value="last-child">Last</option>';
		}
		
		die($order_select);
	default:
}

if ( $apply !== false ){
	header('Location: '.get_current_url());
	exit;
}
header('Location: index.php?view=pages');
exit;