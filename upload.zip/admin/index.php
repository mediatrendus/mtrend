<?php
define('APP', 'administrator');
session_start();
require_once dirname(__FILE__).'/../functions.php';
if ( !file_exists(ABS.'/admin/config.json') || (is_writable(ABS.'/admin/config.json') && filesize(ABS.'/admin/config.json') < 100) ){
	header('Location: ../install.php');
	exit;
}
if ( !get_admin_infomation() ){
	define('USERNAME', 'admin');
	define('PASSWORD', '21232f297a57a5a743894a0e4a801fc3');
}

$c = get_var('c');
if ( $controller = get_controller($c) ){
	require_once $controller;
}

$view = get_var('view');
$task = get_var('task');

if ( $task == 'login' && isset($_POST['username']) ){
	$u = get_var('username');
	$p = get_var('password');
	if ( empty($u) ){
		push_message( 'Username can not empty!', 'danger');
	} else {
		if ( (strcmp($u, USERNAME) === 0) && (md5($p) === PASSWORD) ) {
			$_SESSION['id'] = $u;
		} else {
			push_message( 'Username or Password does not match!', 'danger');
		}
	}

	// header('Location: '.get_current_url());
}

if( get_var('view') == 'logout' && is_logged_in() ){
	session_destroy();
	header('Location: index.php');
}

// load config array
$config_array	=	get_data();

if ( $task == 'settings' ){
	
	$array = array( );
	foreach ( $_REQUEST['settings'] as $row ){
		
		if ( !isset($row['field_name']) || empty($row['field_name']) ){
			continue;
		}
		
		if ( !isset($row['field_value']) || empty($row['field_value']) ){
			$row['field_value'] = '';
		} else if ( !preg_match('/code/', $row['field_name'] ) ){
			$row['field_value'] = filter_var($row['field_value'], FILTER_SANITIZE_STRING);
		}
		
		$array[$row['id']] = $row;
	}
	foreach ($config_array['tables']['settings'] as $i => $setting){
		$j = $setting['id'];
		if ( isset( $array[$j] ) ){
			foreach ( $array[$j] as $n => $v ){
				$config_array['tables']['settings'][$i][$n] = $v;
			}
		}
	}
	save_data($config_array);
	header('Location: '.get_current_url());
	
} else if ($task == 'categories'){
	$max_id = 0;
	$has_change = false;
	$categories = array();
	if ( !isset($config_array['tables']['categories']) ){
		$config_array['tables']['categories'] = array();
	} else {
		foreach ($config_array['tables']['categories'] as $cid => $category){
			if ( $category['id'] > $max_id ) {
				$max_id = $category['id'];
			}
			$categories[$category['id']] = &$config_array['tables']['categories'][$cid];
		}
	}
	$delete_id = get_var('delete');
	if ( isset($_REQUEST['categories']) && empty($delete_id)){
		foreach ( $_REQUEST['categories'] as $cat ){
			$cid = !empty($cat['id']) ? $cat['id'] : $max_id+1;
			$is_update = isset($categories[$cid]);
			
			if ( isset($categories[$cid]) ){
				
				// exists category
				if ( !isset($cat['name']) || empty($cat['name']) ){
					
					// delete it
					unset($config_array['tables']['categories'][$cid]);
					$has_change = true;
				} else {
					
					// update name ?
					if ( $cat['name'] != $categories[$cid]['name'] ){
						$categories[$cid]['name'] = $cat['name'];
						$has_change = true;
					}
					
					// update name ?
					if ( $cat['icon'] != $categories[$cid]['icon'] ){
						$categories[$cid]['icon'] = $cat['icon'];
						$has_change = true;
					}
					
					// update parent ?
					if ( isset($cat['parent']) && $cat['parent'] != $categories[$cid]['parent'] ){
						$categories[$cid]['parent'] = $cat['parent'];
						$has_change = true;
					}
				}
			} else {
				if ( !isset($cat['name']) || empty($cat['name']) ){
					// noop
				} else {
					$newcat = array( 'id' => $cid );
					$newcat['name'] = $cat['name'];
					$newcat['icon'] = $cat['icon'];
					if ( isset($cat['parent']) ){
						$newcat['parent'] = $cat['parent'];
					}
					$newcat['feeds'] = array();
					$config_array['tables']['categories'][$cid] = $newcat;
					$has_change = true;
				}
			}
		}
	} else if ( $delete_id > 0 && isset($categories[$delete_id]) ){
		// remove cat
		unset( $config_array['tables']['categories'][$delete_id] );
		$has_change = true;
	}
	
	if ($has_change){
		save_data($config_array);
		header('Location: '.get_current_url());
	}
} else if ($task == 'feeds'){
	// TODO: process feeds submit
	$max_id = 0;
	$has_change = false;
	$categories = array();
	$feeds = array();
	$childs = array();
	if ( !isset($config_array['tables']['categories']) ){
		$config_array['tables']['categories'] = array();
	} else {
		foreach ($config_array['tables']['categories'] as $cid => $category){
			if ( isset($category['feeds']) && !empty($category['feeds']) ){
				foreach( $category['feeds'] as $fid => $feed ){
					if ( $feed['id'] > $max_id ) {
						$max_id = $feed['id'];
					}
					$feeds[$feed['id']] = &$config_array['tables']['categories'][$cid]['feeds'][$fid];
					$feeds[$feed['id']]['parent'] = $childs[$feed['id']] = $cid;
					$childs[$feed['id']] = $cid;
				}
			}
			$categories[$cid] = &$config_array['tables']['categories'][$cid];
		}
	}
	$delete_id = get_var('delete');
	if ( isset($_REQUEST['feeds']) && empty($delete_id)){
		foreach ( $_REQUEST['feeds'] as $feed ){
			$fid = !empty($feed['id']) ? $feed['id'] : $max_id+1;
			$is_update = isset($feeds[$fid]);
				
			if ( isset($feeds[$fid]) ){
	
				// exists feed
				if ( !isset($feed['url']) || empty($feed['url']) ){
						
					// delete it
					unset($categories[$childs[$delete_id]]['feeds'][$fid]);
					$has_change = true;
				} else {
						
					// update url ?
					if ( $feed['url'] != $feeds[$fid]['url'] ){
						$feeds[$fid]['url'] = $feed['url'];
						$has_change = true;
					}
						
					// update name ?
					if ( isset($feed['name']) && $feed['name'] != $feeds[$fid]['name'] ){
						$feeds[$fid]['name'] = $feed['name'];
						$has_change = true;
					}
					
					// update parent ?
					if ( isset($feed['parent']) && $feed['parent'] != $feeds[$fid]['parent'] ){
						$feeds[$fid]['parent'] = $feed['parent'];
						$has_change = true;
					}
				}
			} else {
				if ( !isset($feed['url']) || empty($feed['url']) ){
					// noop
				} else {
					
					$newfed = array( 'id' => $fid );
					
					$newfed['url'] = $feed['url'];
					$newfed['name'] = $feed['name'];
					
					if ( isset($feed['parent']) ){
						$newfed['parent'] = $feed['parent'];
					}
					$config_array['tables']['categories'][get_var('id')]['feeds'][$fid] = $newfed;
					$has_change = true;
				}
			}
		}
	} else if ( $delete_id > 0 && isset($feeds[$delete_id]) ){
		// remove feed
		unset( $categories[$childs[$delete_id]]['feeds'][$delete_id] );
		$has_change = true;
	}
	
	if ($has_change){
		save_data($config_array);
		header('Location: '.get_current_url());
	}
} else if ($task == 'maintenance'){
	if ( isset($_POST['download']) ){
		$conf = ABS.'/admin/config.json';
		if ( file_exists($conf) && is_readable($conf) ){
			force_download($conf);
			exit;
		} else {
			push_message($conf . ' counld not be read!');
			header('Location: '.get_current_url());
		}
	} else if ( isset($_POST['purgecache']) ){
		$location = get_setting('simplepie_cache_location');
		if ( !empty($location) && file_exists($location) ){
			delete_directory($location, false);
		}
		header('Location: '.get_current_url());
	} else if ( isset($_POST['add_setting'] ) ){
		$setting_name = get_var('setting_name');
		$inputs = preg_split('/[\s,]/', $setting_name, -1, PREG_SPLIT_NO_EMPTY);
		$array = array();
		
		if ( isset($inputs[0]) ) $array['field_name'] = $inputs[0];
		if ( isset($inputs[1]) ) $array['field_type'] = $inputs[1];
		if ( isset($inputs[2]) ){
			$nvps = explode('|', $inputs[2]);
			$choices = array();
			foreach ( $nvps as $nv ){
				list($k, $v) = explode(';', $nv);
				$choices[$k] = ucfirst($v);
			}
			$array['field_choices'] = $choices;
		}
		add_setting( $array );
		header('Location: '.get_current_url());
	} else if ( isset($_POST['rev_setting'] ) ){
		delete_setting( get_var('setting_name') );
		header('Location: '.get_current_url());
	} else if ( isset($_POST['admin_users']) ){
		$admin_username = get('admin_username', '', $_POST);
		$admin_password = get('admin_password', '', $_POST);
		if ( empty($admin_username) || empty($admin_password) ){
			push('Username or Password can not be empty!', 'danger');
		} else {
			$config_array['tables']['users'] = array(
				'username' => $admin_username,
				'password' => md5($admin_password)
			);
			save_data($config_array);
			unset($_SESSION['id']);
			session_destroy();
		}
		header('Location: '.get_current_url());
	}
}


if ( isset($config_array['tables']['settings']) ){
	foreach ( $config_array['tables']['settings'] as $element ){
		if ( !isset($element['field_value']) || !is_string($element['field_value']) ){
			//var_dump( $element['field_value'] );
			continue;
		}
		$$element['field_name'] = htmlspecialchars($element['field_value'], ENT_COMPAT, 'UTF-8');
	}
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<base href="<?php echo $site_url . 'admin/'; ?>">
	<meta charset="utf-8">
	<meta content="width=device-width, initial-scale=1.0" name="viewport">
	<link href="../assets/ico/favicon.png" rel="shortcut icon">
	<title><?php echo $site_name; ?> - Adminsitrator</title>
	<?php if ( !isset($theme_name) ) $theme_name = 'default'; ?>
	<link href="../assets/css/themes/<?php echo $theme_name; ?>/bootstrap.min.css" rel="stylesheet">
	<?php if ( get_setting('enable_rtl') == '1' ): ?>
	<link href="../assets/css/bootstrap-rtl.min.css" rel="stylesheet">
	<?php endif; ?>
    <link href="../assets/css/font-awesome.min.css" rel="stylesheet">
	<link href="../assets/css/app.css" rel="stylesheet">
	<script type="text/javascript" src="../assets/js/jquery-2.0.0.min.js"></script>
	<script type="text/javascript" src="../assets/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="../assets/js/jquery.cleditor.min.js"></script>
	<!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
</head>
<body>
	<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
	  	<!-- Brand and toggle get grouped for better mobile display -->
	  	<div class="navbar-header">
	    	<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
	      		<span class="sr-only">Toggle navigation</span>
	      		<span class="icon-bar"></span>
	      		<span class="icon-bar"></span>
	      		<span class="icon-bar"></span>
	    	</button>
	    	<a class="navbar-brand" href="<?php echo $site_url; ?>"><?php echo $site_name; ?></a>
	  	</div>
	
	  	<!-- Collect the nav links, forms, and other content for toggling -->
	  	<div class="collapse navbar-collapse navbar-ex1-collapse">
	  		<?php require_once get_view('navbar'); ?>
	  	</div><!-- /.navbar-collapse -->
	</nav>
	
	<?php
	if( !is_logged_in() ){
	?>
	<div class="container">
		<div class="page-header">
        	<h1 class="text-center">Admin Login</h1>
      	</div>
      	<?php print_messages(); ?>
      	<form class="form-horizontal" enctype="multipart/form-data" method="post" accept-charset="utf-8">
	      	<div class="panel panel-default">
	      		<div class="panel-heading">
	      			&nbsp;
	      		</div>
	      		<div class="panel-body">
					<form class="form-horizontal" id="loginform" enctype="multipart/form-data" method="post" accept-charset="utf-8">
						<div class="form-group ">
							<label for="username" class="control-label col-lg-4"> Username: * </label>
							<div class="controls col-lg-4">
								<input class="form-control" name="username" value="" type="text" id="username">
							</div>
						</div>
						
						<div class="form-group">
							<label for="username" class="control-label col-lg-4"> Password: * </label>
							<div class="controls col-lg-4">
								<input class="form-control" name="password" value="" type="password" id="password">
							</div>
						</div>
						
						<div class="form-group">
							<div class="col-lg-offset-4 col-lg-4">
								<button class="btn btn-primary" type="submit">Sign in</button>
								<button class="btn btn-default" type="reset">Reset</button>
							</div>
						</div>
						<input type="hidden" value="login" name="task">
					</form>
				</div>
				<div class="panel-footer">
					&nbsp;
	      		</div>
			</div>
			<input type="hidden" name="task" value="categories" />
			<input type="hidden" name="delete" value="" />
		</form>
	</div>
	<?php
	} else {
		$view = get_var('view');
		
		if ( $view == 'categories'):
		?>
		<div class="container">
			<div class="page-header">
	        	<h1 class="text-center">Management : Categories</h1>
	      	</div>
	      	<?php print_messages(); ?>
	      	<form class="form-horizontal" enctype="multipart/form-data" method="post" accept-charset="utf-8">
		      	<div class="panel panel-default">
		      		<div class="panel-heading">
						<div class="text-right">
							<button class="btn btn-primary" type="submit"> Save </button>
							<a class="btn btn-default" href="index.php"> <i class="icon-refresh"></i> Cancel</a>
						</div>
		      		</div>
		      		<div class="panel-body">
						<div class="form-group">
							<label class="control-label col-lg-1 visible-lg">#</label>
							<div class="col-lg-7 visible-lg" style="padding-top: 9px;"><b>Name</b></div>
							<div class="col-lg-4 visible-lg" style="padding-top: 9px;"><b>Action</b></div>
						</div>
						<?php
						$j = 1;
						$categories	= isset($config_array['tables']['categories']) ? $config_array['tables']['categories'] : array();
						if ( count($categories) ):
							foreach ($categories as $category){
								// var_dump( $category );
								if ( !isset($category['icon']) ){
									$category['icon'] = '';
								}
								?>
								<div class="form-group">
									<label for="cname_<?php echo $j; ?>" class="col-lg-1 control-label"><?php echo $j; ?></label>
									<div class="col-lg-3">
										<div class="input-group">
											<input type="text" class="form-control caticon" name="categories[<?php echo $j; ?>][icon]" value="<?php echo $category['icon']; ?>">
											<span class="input-group-addon caticon-preview"><?php if (!empty($category['icon'])): ?><i class="<?php echo $category['icon']; ?>"></i><?php endif; ?></span>
										</div>
									</div>
									<div class="col-lg-4">
										<input class="form-control" name="categories[<?php echo $j; ?>][id]"   value="<?php echo $category['id']; ?>"   type="hidden" />
										<input class="form-control" name="categories[<?php echo $j; ?>][name]" value="<?php echo $category['name']; ?>" type="text" id="cname_<?php echo $j; ?>">
									</div>
									<div class="col-lg-4">
										<div class="text-left">
											<button class="btn btn-danger" type="submit" data-delete="<?php echo $category['id']; ?>"><i class="icon-trash"></i> Delete</button>
											<a class="btn btn-success" href="index.php?view=feeds&id=<?php echo $category['id']; ?>"><i class="icon-plus"></i> Feeds</a>
										</div>
									</div>
								</div>
								<?php
								$j++;
							}
						endif;
						?>
						<div class="form-group">
							<label for="cname_<?php echo $j; ?>" class="col-lg-1 control-label"><?php echo $j; ?></label>
							<div class="col-lg-3">
								<div class="input-group">
									<input type="text" class="form-control caticon" name="categories[<?php echo $j; ?>][icon]" value="">
									<span class="input-group-addon caticon-preview"></span>
								</div>
							</div>
							<div class="col-lg-4">
								<input class="form-control" name="categories[<?php echo $j; ?>][id]"   value="" type="hidden" />
								<input class="form-control" name="categories[<?php echo $j; ?>][name]" value="" type="text" id="cname_<?php echo $j; ?>">
							</div>
							<div class="col-lg-4">
								<div class="text-left">
									<button class="btn btn-success" type="submit"><i class="icon-plus"></i> Update</button>
								</div>
							</div>
						</div>
					</div>
					<div class="panel-footer">
						<div class="text-right">
							<button class="btn btn-primary" type="submit"> Save </button>
							<a class="btn btn-default" href="index.php"> <i class="icon-refresh"></i> Cancel</a>
						</div>
		      		</div>
				</div>
				<input type="hidden" name="task" value="categories" />
				<input type="hidden" name="delete" value="" />
			</form>
		</div>
		<?php
		elseif ( $view == "feeds" ):
			$category = get_var('id');
		?>
		<div class="container">
			<div class="page-header">
	        	<h1 class="text-center">Management : Feeds <?php echo $category ? ' in ' . get_category_name($category) : ''; ?></h1>
	      	</div>
	      	<?php print_messages(); ?>
	      	<form class="form-horizontal" enctype="multipart/form-data" method="post" accept-charset="utf-8">
		      	<div class="panel panel-default">
		      		<div class="panel-heading">
						<div class="text-right">
							<button class="btn btn-primary" type="submit"> Save </button>
							<a class="btn btn-default" href="index.php?view=categories"> <i class="icon-refresh"></i> Cancel</a>
						</div>
		      		</div>
		      		<div class="panel-body">
						<div class="form-group">
							<label class="control-label col-lg-1 visible-lg">#</label>
							<div class="col-lg-2 visible-lg" style="padding-top: 9px;"><b>Name</b></div>
							<div class="col-lg-7 visible-lg" style="padding-top: 9px;"><b>Url</b></div>
							<div class="col-lg-2 visible-lg" style="padding-top: 9px;"><b>Action</b></div>
						</div>
						<?php
						$j = 1;
						$feeds	= get_all_feeds($category);
						if ( count($feeds) ):
							foreach ($feeds as $feed){
								?>
								<div class="form-group">
									<label for="furl_<?php echo $j; ?>" class="col-lg-1 control-label"><?php echo $j; ?></label>
									<div class="col-lg-2">
										<input class="form-control" name="feeds[<?php echo $j; ?>][id]"   value="<?php echo $feed['id']; ?>"   type="hidden" />
										<input class="form-control" name="feeds[<?php echo $j; ?>][name]" value="<?php echo $feed['name']; ?>" type="text" id="fname_<?php echo $j; ?>">
									</div>
									<div class="col-lg-7">
										<input class="form-control" name="feeds[<?php echo $j; ?>][url]" value="<?php echo $feed['url']; ?>" type="text" id="furl_<?php echo $j; ?>">
									</div>
									<div class="col-lg-2">
										<div class="text-left">
											<button class="btn btn-danger" type="submit" data-delete="<?php echo $feed['id']; ?>"><i class="icon-trash"></i> Delete</button>
										</div>
									</div>
								</div>
								<?php
								$j++;
							}
						endif;
						?>
						<div class="form-group">
							<label for="fname_<?php echo $j; ?>" class="col-lg-1 control-label"><?php echo $j; ?></label>
							<div class="col-lg-2">
								<input class="form-control" name="feeds[<?php echo $j; ?>][id]" value="" type="hidden" />
								<input class="form-control" name="feeds[<?php echo $j; ?>][name]" value="" type="text" id="fname_<?php echo $j; ?>">
							</div>
							<div class="col-lg-7">
								<input class="form-control" name="feeds[<?php echo $j; ?>][url]" value="" type="text" id="furl_<?php echo $j; ?>">
							</div>
							<div class="col-lg-2">
								<div class="text-left">
									<button class="btn btn-success" type="submit"><i class="icon-plus"></i> Update</button>
								</div>
							</div>
						</div>
					</div>
					<div class="panel-footer">
						<div class="text-right">
							<button class="btn btn-primary" type="submit"> Save </button>
							<a class="btn btn-default" href="index.php?type=categories"> <i class="icon-refresh"></i> Cancel</a>
						</div>
		      		</div>
				</div>
				<input type="hidden" name="task" value="feeds" />
				<input type="hidden" name="delete" value="" />
			</form>
		</div>
		<?php
		elseif ( $view == 'settings' ):
			include_once get_view($view);
		elseif ( $view == "pages" ):
			include_once get_view($view);
		elseif ( $view == 'maintenance' ):
			require_once get_view($view);
		elseif ( $view == 'ads' ):
			require_once get_view($view);
		else :
		?>
		<div class="container">
			<div class="page-header">
	        	<h1 class="text-center">Management : Dashboard</h1>
	      	</div>
	      	<?php print_messages(); ?>
	      	<div class="panel panel-default">
	      		<div class="panel-heading">
					<div class="text-right">
						<h2>Hello Admin!</h2>
					</div>
	      		</div>
	      		<div class="panel-body">
	      			<ul class="list-inline text-center">
	      				<li>
	      					<div class="thumbnail dashboard">
	      						<a href="index.php?view=categories" title="Categories">
	      							<span class="icon-th-list dashboard-thumbnail"></span>
	      						</a>
	      						<div class="caption">
	      							<a href="index.php?view=categories" title="Categories">Categories</a>
	      						</div>
	      					</div>
	      				</li>
	      				<li>
	      					<div class="thumbnail dashboard">
	      						<a href="index.php?view=pages" title="Pages">
	      							<span class="icon-book dashboard-thumbnail"></span>
	      						</a>
	      						<div class="caption">
	      							<a href="index.php?view=pages" title="Pages">Pages</a>
	      						</div>
	      					</div>
	      				</li>
	      				<li>
	      					<div class="thumbnail dashboard">
	      						<a href="index.php?view=ads" title="Ads">
	      							<span class="icon-picture dashboard-thumbnail"></span>
	      						</a>
	      						<div class="caption">
	      							<a href="index.php?view=ads" title="Ads">Ads</a>
	      						</div>
	      					</div>
	      				</li>
	      				<li>
	      					<div class="thumbnail dashboard">
	      						<a href="index.php?view=settings" title="Settings">
	      							<span class="icon-cogs dashboard-thumbnail"></span>
	      						</a>
	      						<div class="caption">
	      							<a href="index.php?view=settings" title="Settings">Settings</a>
	      						</div>
	      					</div>
	      				</li>
	      				<li>
	      					<div class="thumbnail dashboard">
	      						<a href="index.php?view=maintenance" title="Maintenance">
	      							<span class="icon-hdd dashboard-thumbnail"></span>
	      						</a>
	      						<div class="caption">
	      							<a href="index.php?view=maintenance" title="Maintenance">Maintenance</a>
	      						</div>
	      					</div>
	      				</li>
	      			</ul>
	      		</div>
	      	</div>
		</div>
		
		<?php
		endif;
	}
	?>
	<footer>
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<p>Copyright &copy; <?php echo date('Y'); ?> by <?php echo $site_name; ?> <?php echo VERSION; ?>.</p>
				</div>
			</div>
		</div>
	</footer>
	<script type="text/javascript">
		jQuery(function($){
			$(document).on('click', '[data-delete]', function(e){
				e.preventDefault();
				var $this = $(this), data = $this.data();
				var $form = $this.parents('form'), $inp = $form.find('[name="delete"]');
				$inp.val(data['delete']);
				$form.submit();
			});
			$('.caticon').change(function(){
				var $this = $(this), $preview = $this.siblings('.caticon-preview');
				$preview.empty().append('<i class="'+ $this.val() +'"></i>');
			});


			$("#editor").cleditor();
			
			$('#cron_exec').on('click', function(e){
				e.preventDefault();
				var btn = $(this);
				btn.find('i').show();
				$.ajax({
					url: 'index.php?c=cron',
					data: {},
					success: function(resp){
						btn.find('i').hide();
						// $('#last_cron').text( (new Date()).toString() );
						$('#cron_messages').append(resp);
						setTimeout(function(){
							$('#cron_messages').find('> div').hide(500, function(){
								$(this).remove();
							});
						}, 3000);
					}
				});
			});
		});
	</script>
</body>
</html>