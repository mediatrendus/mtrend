<div class="container">
			<div class="page-header">
	        	<h1 class="text-center">Management : Maintenance</h1>
	      	</div>
	      	<?php print_messages(); ?>
	      	<div id="cron_messages">
    		</div>
	      	<form class="form-horizontal" enctype="multipart/form-data" method="post" accept-charset="utf-8">
		      	<div class="panel panel-default">
		      		<div class="panel-heading">
						<div class="text-right">
							<a class="btn btn-default" href="index.php"> <i class="icon-refresh"></i> Cancel </a>
						</div>
		      		</div>
		      		<div class="panel-body">
		      			<div class="form-group ">
							<label class="control-label col-lg-2"></label>
							<div class="col-lg-7">
								<button class="btn btn-primary" id="cron_exec">Run Cron / Update Feeds  <i style="display: none;" class="icon-refresh icon-spin"></i></button>
								<label class="control-label" id="last_cron"></label>
							</div>
						</div>
						<div class="form-group ">
							<?php $configuration = ABS.'/admin/config.json'; ?>
							<label class="control-label col-lg-2">Configuration</label>
							<div class="col-lg-7">
								<input type="text" class="form-control" readondy="true" value="<?php echo $configuration; ?>" />
							</div>
							<div class="col-lg-2">
								<?php if (file_exists($configuration) && is_readable($configuration)): ?>
								<input type="submit" class="btn btn-default form-control" name="download" value="Download" />
								<?php elseif( !is_readable($configuration) ): ?>
								<input type="submit" class="btn btn-default form-control" disabled="disabled" name="download" value="Not Readable" />
								<?php elseif( !file_exists($configuration) ): ?>
								<input type="submit" class="btn btn-default form-control" disabled="disabled" name="download" value="Not Exists" />
								<?php endif; ?>
							</div>
						</div>
						<div class="form-group ">
							<?php $location = get_setting('simplepie_cache_location'); ?>
							<label class="control-label col-lg-2">Cache Location</label>
							<div class="col-lg-7">
								<input type="text" class="form-control" readondy="true" value="<?php echo !empty($location)? $location : ''; ?>" />
							</div>
							<div class="col-lg-2">
								<?php if ( !file_exists($location) ): ?>
								<input type="submit" class="btn btn-default form-control" disabled="disabled" name="purgecache" value="Purge Cache"  />
								<?php elseif( count_in_directory($location) == 0): ?>
								<input type="submit" class="btn btn-default form-control" disabled="disabled" name="purgecache" value="Cache Empty" title="Empty!"/>
								<?php else: ?>
								<div class="btn-group">
									<button type="submit" class="btn btn-default" name="purgecache">Purge Cache</button>
									<?php if ($categories = get_categories()): ?>
									<button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
										<span class="caret"></span> <span class="sr-only">Toggle Dropdown</span>
									</button>
									<ul class="dropdown-menu" role="menu">
										<?php foreach ($categories as $cat): ?>
										<li><a href="index.php?c=cache&id=<?php echo $cat['id']; ?>"> <?php if( isset($cat['icon']) ): ?><i class="icon-<?php echo $cat['icon']; ?>"></i> <?php endif; echo $cat['name']; ?></a></li>
										<?php endforeach; ?>
									</ul>
									<?php endif; ?>
								</div>
								<?php endif; ?>
							</div>
						</div>
						
						<div class="form-group ">
							<label class="control-label col-lg-2">Setting Name</label>
							<div class="col-lg-5">
								<input type="text" class="form-control" name="setting_name" value="" />
							</div>
							<div class="col-lg-2">
								<input type="submit" class="btn btn-success form-control" name="add_setting" value="Add Setting" />
							</div>
							<div class="col-lg-2">
								<input type="submit" class="btn btn-danger form-control" name="rev_setting" value="Remove Setting" />
							</div>
						</div>
						
						<hr/>
						<div class="form-group ">
							<label class="control-label col-lg-2">Admin Username</label>
							<div class="col-lg-2">
								<input type="text" class="form-control" name="admin_username" value="<?php echo USERNAME; ?>" />
							</div>
							<label class="control-label col-lg-2">Admin Password</label>
							<div class="col-lg-2">
								<input type="password" class="form-control" name="admin_password" value="" />
							</div>
							<div class="col-lg-3">
								<input type="submit" class="btn btn-danger form-control" name="admin_users" value="Change Username or Password" />
							</div>
						</div>
						
		      			<input type="hidden" name="task" value="maintenance" />
		      		</div>
		      		<div class="panel-footer">
						<div class="text-right">
							<a class="btn btn-default" href="index.php"> <i class="icon-refresh"></i> Cancel </a>
						</div>
					</div>
		      	</div>
		    </form>
	    </div>