		<div class="container">
			<div class="page-header">
	        	<h1 class="text-center">Management : Settings</h1>
	      	</div>
	      	
	      	<?php print_messages(); ?>
	      	<form class="form-horizontal" id="SettingPrefixForm" enctype="multipart/form-data" method="post" accept-charset="utf-8">
		      	<div class="panel panel-default">
		      		<div class="panel-heading">
						<div class="text-right">
							<button class="btn btn-primary" type="submit"> Save </button>
							<a class="btn btn-default" href="index.php"> <i class="icon-refresh"></i> Cancel </a>
						</div>
		      		</div>
		      		<div class="panel-body">
		      			<?php
		      				$row_no=0;
		      				
							$settings = $config_array['tables']['settings'];
							foreach($settings as $setting_data){
								$row_no++;
								if ( $setting_data['field_name'] == 'theme_name' ){
									$setting_data['field_type'] = 'select';
									$setting_data['field_choices'] = array(
										'amelia'   => 'Amelia',
										'cerulean' => 'Cerulean',
										'cosmo'    => 'Cosmo',
										'cyborg'   => 'Cyborg',
										'default'  => 'Default',
										'flatly'   => 'Flatly',
										'journal'  => 'Journal',
										'readable' => 'Readable',
										'simplex'  => 'Simplex',
										'slate'    => 'Slate',
										'spacelab' => 'Spacelab',
										'united'   => 'United'
									);
								}
								
								if (isset($setting_data['field_name'])){
									$setting_field_cb = $setting_data['field_name'] . '_callback';
									if ( is_callable($setting_field_cb) ){
										$setting_data = call_user_func($setting_field_cb, array('setting'=>$setting_data));
									}
								}
							?>
							<div class="form-group ">
								<label for="Setting<?php echo $row_no; ?>Value" class="col-lg-2 control-label"><?php echo pretty_name($setting_data['field_name']); ?></label>
								<div class="col-lg-10">
									<input class="form-control" name="settings[<?php echo $row_no; ?>][id]" value="<?php echo @$setting_data['id']; ?>" type="hidden">
									<input class="form-control" name="settings[<?php echo $row_no; ?>][field_name]" value="<?php echo $setting_data['field_name']; ?>" type="hidden">
									<?php if ( isset($setting_data['field_type']) && $setting_data['field_type']=='select' ): ?>
									<select class="form-control" name="settings[<?php echo $row_no; ?>][field_value]" value="<?php echo $setting_data['field_value']; ?>" id="Setting<?php echo $row_no; ?>Value">
										<?php if ( isset($setting_data['field_choices']) && count($setting_data['field_choices']) ): ?>
										<?php foreach ($setting_data['field_choices'] as $value => $label): ?>
										<option<?php if(isset($setting_data['field_value']) && $setting_data['field_value']==$value) echo ' selected'; ?> value="<?php echo $value; ?>"><?php echo $label; ?></option>
										<?php endforeach; ?>
										<?php endif; ?>
									</select>
									<?php elseif ( isset($setting_data['field_type']) && $setting_data['field_type']=='textarea' ): ?>
									<?php $rows = isset($setting_data['field_rows']) ? $setting_data['field_rows'] : 5;	?>
									<textarea  class="form-control" name="settings[<?php echo $row_no; ?>][field_value]" rows="<?php echo $rows; ?>"><?php echo $setting_data['field_value']; ?></textarea>
									<?php else: ?>
									<input class="form-control" name="settings[<?php echo $row_no; ?>][field_value]" value="<?php echo $setting_data['field_value']; ?>" type="text" id="Setting<?php echo $row_no; ?>Value">
									<?php endif; ?>
								</div>
							</div>
						<?php
							}
						?>
		      			<input type="hidden" name="task" value="settings" />
		      		</div>
		      		<div class="panel-footer">
						<div class="text-right">
							<button class="btn btn-primary" type="submit"> Save </button>
							<a class="btn btn-default" href="index.php"> <i class="icon-refresh"></i> Cancel </a>
						</div>
					</div>
		      	</div>
		    </form>
	    </div>