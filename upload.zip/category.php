<?php
defined('ABS') or die;

$category = get_category_by_seoname( get_command(0) );
if ( preg_match('/youtube/i', $category['name']) ){
	$is_youtube = true;
} else {
	$is_youtube = false;
}
// Set our paging values
if(is_numeric( get_command(0) )){
	$page = get_command(0);
} else if (is_numeric(get_command(1))){
	$page = get_command(1);
} else {
	$page = 0;
}

if($page == '')
	$start		=	0;
else
	$start		=	$page * $category_page_limit;
	
$length = $category_page_limit;

$all_items = load_all_feeds( get_feed_urls($category['id']) );

if ( count($all_items) ){
	$feeds = array(
		'cname' => @$category['name'],
		'cicon' => @$category['icon'],
		'feed_count' => count($all_items),
		'founds' => array()
	);
	foreach ( $all_items as $item ){
		if ( !isset($keyword)
				|| empty($keyword)
				|| (preg_match("/$keyword/i", $item->get_title())
						|| preg_match("/$keyword/i", $item->get_content())) ) {
			$feeds['founds'][] = $item;
			
			get_feed_thumbnail($item, $category);
		}
	}
} else {
	$feeds = array(
			'cname' => $cname,
			'cicon' => $cicon,
			'feed_errors' => '',
			'founds' => array()
	);
}
$max = count($feeds['founds']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<base href="<?php echo $site_url; ?>" />
	<meta charset="utf-8">
	<meta content="width=device-width, initial-scale=1.0" name="viewport">
	<meta name="description" content="Read the Latest <?php echo ucfirst( $category['name'] ); ?> headlines at <?php echo $site_name; ?>  <?php echo get_command(1) ? "page " . get_command(1) : ""; ?>">
	<meta name="keywords" content="<?php echo ucfirst( $category['name'] ); ?>s healed, <?php echo ucfirst( $category['name'] ); ?>s, <?php echo ucfirst( $category['name'] ); ?>s articles">
	<title>Latest <?php echo ucfirst( $category['name'] ); ?> headlines <?php echo get_command(1) ? "page " . get_command(1) : ""; ?> - <?php echo $site_name; ?></title>
	
	<link rel="canonical" href="<?php echo get_current_url(); ?>">
	<link rel="alternate" type="application/rss+xml" title="<?php echo $site_name; ?> Feed" href="<?php echo get_site_url( array('feed', get_command(0)) ); ?>" />
	<link href="assets/ico/favicon.png" rel="shortcut icon">

	<?php if ( !isset($theme_name) ) $theme_name = 'default'; ?>
	<link href="assets/css/themes/<?php echo $theme_name; ?>/bootstrap.min.css" rel="stylesheet">
	<?php if ( get_setting('enable_rtl') == '1' ): ?>
	<link href="assets/css/bootstrap-rtl.min.css" rel="stylesheet">
	<?php endif; ?>
	<link href="assets/css/font-awesome.min.css" rel="stylesheet">
	<link href="assets/css/app.css" rel="stylesheet">
	
<?php if ( !defined('APP') && get_raw_setting('head_code') ){
	echo get_raw_setting('head_code');
} ?>
</head>

<body class="category category-<?php echo $category['id']; ?>" style="margin-top: 0px;">
	
	<?php require_once ABS.'/nav.php'; ?>
	
	<div class="container">
		<div class="page-header">
			<?php
				$cicon = '<i class="'.$category['icon'].'"></i>';
			?>
        	<h1><a href="<?php echo get_site_url( get_seoname($category['name']) ); ?>"><?php echo $cicon; ?> <?php echo ucfirst($category['name']); ?> Magazine</a></h1>
       		<p class="lead">Discover and Read Popular <?php echo ucfirst($category['name']); ?> Articles</p>
      	</div>
    </div>
    
	<div class="container">
		<?php
		$layout_active = isset($default_layout) ? $default_layout : 'list';
		if ( empty($layout_active) ) $layout_active = 'list';
		?>
					<div class="text-center"><?php display_banner(1); ?></div>

		<section class="feeds <?php echo $layout_active; ?>">
			<div class="row">
			<div class="col-md-12"></div>
			<div class="col-md-12">
			<div class="feeds-control pull-right">
				<div id="layout-switcher" class="btn-group visible-lg visible-md visible-sm" data-toggle="buttons">
					<label class="btn btn-primary<?php echo $layout_active=='grid'?' active':''; ?>">
						<input type="radio" name="layout" group="layout" value="grid" <?php echo $layout_active=='grid'?' checked="checked"':''; ?>><i class="icon-th-large"></i>
					</label>
					<label class="btn btn-primary<?php echo $layout_active=='list'?' active':''; ?>">
						<input type="radio" name="layout" group="layout" value="list" <?php echo $layout_active=='list'?' checked="checked"':''; ?>><i class="icon-th-list"></i>
					</label>
				</div>
			</div>
			</div>
			</div>

			<?php
	   		
	   		$items = array_slice($feeds['founds'], $start, $category_page_limit);
		   	if ( count($items) ):
		   	?>
		   	<div class="row">
		   		<?php foreach($items as $item):
		   		if ( !($item instanceof SimplePie_Item) ){
		   			$item = get_cached_item($item);
		   		}
			   		$item_url = $site_url.'article/'.get_seoname( $category['name'] ).'/' .get_seoname( $item->get_title() );
			   		?>
			   		<div class="media col-xs-12<?php echo $layout_active=='grid'?' col-lg-3 col-md-4 col-sm-6':''; ?>" data-grid="col-lg-3 col-md-4 col-sm-6">
	   					<a class="pull-left" href="<?php echo $item_url; ?>" <?php if(isset($thumbnail_height) &&$thumbnail_height>0): ?>style="height:<?php echo $thumbnail_height; ?>px; overflow: hidden;"<?php endif; ?>>
	   						<img class="media-object thumbnail" src="<?php echo get_feed_thumbnail($item, $category); ?>" alt="<?php echo $item->get_title(); ?>" />
	   					</a>
	   					<div class="media-body">
	   						<h3 class="media-heading"><a class="text-overflow hideOverflow" href="<?php echo $item_url; ?>"><?php echo $item->get_title(); ?></a></h4>
	   						<h4><?php echo $item->get_date(); ?></h4>
	   					</div>
	   				</div>
	   			<?php endforeach; ?>
	   		</div>
	   		<?php
				if( $page > 1 )
					$prevlink		=	"<a href='" . get_site_url( array( get_seoname($category['name']), $page-1 ) ) . "'>Previous</a>";
				else if ( $page == 1 ){
					$prevlink		=	"<a href='" . get_site_url( array( get_seoname($category['name']) ) ) . "'>Previous</a>";
				} else
					$prevlink		=	"";
				
				if( ($page * $category_page_limit + $category_page_limit) < $max)
					$nextlink		=	"<a href='".  get_site_url( array( get_seoname($category['name']), $page+1 ) ) ."'>Next</a>";
				else
					$nextlink		=	"";
				?>
				
				<p>Showing <?php echo min($start+1, $max); ?>&ndash;<?php echo min($start+$category_page_limit, $max); ?> out of <?php echo $max; ?></p>
				<ul class="pager">
					<li class="previous"><?php echo $prevlink; ?></li>
					<li class="next"><?php echo $nextlink; ?></li>
				</ul>
			<?php
			else: ?>
				<p>There are no feed in this category. Please add/correct your feed links <a href="<?php echo $site_url.'admin/index.php?type=categories'; ?>" >here</a>.</p>
				<?php
			endif;
			?>
		</section>
	</div>
	<?php require_once ABS.'/footer.php'; ?>
</body>
</html>