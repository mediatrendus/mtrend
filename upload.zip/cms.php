<?php
defined('ABS') or die;

$page = (isset($front_page_id) && $front_page_id > 0) ? get_page_by_id($front_page_id) : get_page_by_seoname( get_command(1) );
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<base href="<?php echo $site_url; ?>" />
	<meta charset="utf-8">
	<meta content="width=device-width, initial-scale=1.0" name="viewport">
	<meta name="description" content="<?php echo get('meta_description', '', $page); ?>">
	<meta name="keywords" content="<?php echo get('meta_keywords', '', $page); ?>">
	<title><?php echo get('title', '', $page); ?></title>
	
	<link rel="canonical" href="<?php echo get_current_url(); ?>">
	<link href="assets/ico/favicon.png" rel="shortcut icon">

	<?php if ( !isset($theme_name) ) $theme_name = 'default'; ?>
	<link href="assets/css/themes/<?php echo $theme_name; ?>/bootstrap.min.css" rel="stylesheet">
	<?php if ( get_setting('enable_rtl') == '1' ): ?>
	<link href="assets/css/bootstrap-rtl.min.css" rel="stylesheet">
	<?php endif; ?>
	<link href="assets/css/font-awesome.min.css" rel="stylesheet">
	<link href="assets/css/app.css" rel="stylesheet">
	
<?php if ( !defined('APP') && get_raw_setting('head_code') ){
	echo get_raw_setting('head_code');
} ?>
</head>

<body class="page page-<?php echo get('id', '', $page); ?>">
	
	<?php require_once ABS.'/nav.php'; ?>
	
	<div class="container">
		<div class="page-header">
        	<h1><?php echo get('title', '', $page); ?></h1>
      	</div>
    </div>
    
	<div class="container">
		<section class="page-content">
			<?php echo get('content', '', $page); ?>
		</section>
	</div>
	<?php require_once ABS.'/footer.php'; ?>
</body>
</html>