<?php
require_once dirname(__FILE__).'/functions.php';
if ( !file_exists(ABS.'/admin/config.json') || (is_writable(ABS.'/admin/config.json') && filesize(ABS.'/admin/config.json') < 100) ){
	header('Location: ./install.php');
	exit;
}

if ( preg_match('/[A-Z]/', $_SERVER['REQUEST_URI']) && !preg_match('#/preview/#', $_SERVER['REQUEST_URI']) ){
	$uri = strtolower($_SERVER['REQUEST_URI']);
	header('Location: ' . $uri);
	exit;
}

$data = get_data();

if ( isset($data['tables']['settings']) ){
	foreach ( $data['tables']['settings'] as $element ){
		if ( !isset($element['field_value']) || !is_string($element['field_value']) ){
			continue;
		}
		$$element['field_name'] = htmlspecialchars($element['field_value'], ENT_COMPAT, 'UTF-8');
	}
}

$requestURI = explode('/', str_replace("?","/?", $_SERVER['REQUEST_URI']));
$scriptName = explode('/', str_replace("?","/?", $_SERVER['SCRIPT_NAME']));

for($i= 0; $i < count($scriptName); $i++){
	if ( empty($requestURI[$i]) || ($requestURI[$i] == $scriptName[$i]) ){
		unset($requestURI[$i]);
	}
}
$keyword = '';
if( isset($_REQUEST['keyword']) ){
	$keyword = $_REQUEST['keyword'];
}

$command = array_values($requestURI);
if (count($command)){
	foreach ($command as $i => $cmd){
		if ( is_string($cmd) && preg_match('~%[0-9A-F]{2}~i', $cmd) ){
			$command[$i] = urldecode($cmd);
		}
	}
}

if ( @$command[0]=='feed' ){
	require_once ABS.'/rss.php';
} else if( isset($_REQUEST['keyword']) ){
	$command[0] = 'index';
	require_once ABS.'/home.php';
} else if( @$command[0] == 'page' ){
	$command[0] = 'page';
	require_once ABS.'/cms.php';
} else if( @$command[0]=='index' || @$command[0]=='' || is_numeric(@$command[0]) ){
	$command[0]	= 'index';
	if ( ($front_page_id = get_setting('front_page_id', -1)) > 0 ){
		require_once ABS.'/cms.php';
	} else {
		require_once ABS.'/home.php';
	}
} else if( @$command[0] == 'article' ){
	require_once ABS.'/single.php';
} else if( @$command[0] == 'preview' ){
	require_once ABS.'/preview.php';
} else if( @$command[0] == 'search' ) {
	$keyword = urldecode($command[1]);
	$pageName = 'search';
	require_once ABS.'/home.php';
} else {
	if( isset($_REQUEST['keyword']) ){
		$keyword = $_REQUEST['keyword'];
	}
	$pageNumber = isset($command[1]) ? @$command[1]: 0;
	require_once ABS.'/category.php';
	
}
?>