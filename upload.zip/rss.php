<?php
$categories = get_categories();
if ( get_command(1) ){
	$category = get_category_by_seoname( get_command(1) );
	$categories = get_categories($category['id']);
}

$limit = isset($rss_limit) ? $rss_limit : 12;
if ( is_numeric( get_command(2) ) ){
	$limit = get_command(2);
}

$feeds = array();
$feed_count = 0;

if ( count($categories) ){
	$cat_limit = ceil( $limit / count($categories) );
	
	foreach ($categories as $cid => $cat){

		$feed = get_simplepie();
			
		// Set your own configuration options as you see fit.
		$feed->set_feed_url( get_feed_urls( $cat['id'] ) );
		
		if ( $feed->init() ){
			$i = 0;
			foreach ( $feed->get_items() as $item ){
				if ( $i++ < $cat_limit ) {
					$f = new stdClass();
					$f->title = htmlspecialchars($item->get_title(), ENT_COMPAT, 'UTF-8', true);
					$f->description = $item->get_content();
					$f->link = get_site_url(array(
							'article',
							get_seoname( $cat['name'] ),
							get_seoname( $item->get_title() )
					));
					array_push($feeds, $f);
					$feed_count++;
					continue;
				}
				break;
			}
		}
		if ( $limit <= $feed_count ){
			break;
		}
	}
}

header("Content-Type: application/rss+xml");
echo '<?xml version="1.0" encoding="UTF-8"?>';
echo '<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
		<channel>
			<title>' . htmlentities( $site_name ) . '</title>
			<link>' . htmlentities( $site_url ) . '</link>
			<description>' . htmlentities( $site_description ) . '</description>
			<pubDate>' . date( 'D, d M Y H:i:s O' ) . '</pubDate>
			<generator>' . $site_name . ' Feed Generator</generator>
			<language>en</language>
			<atom:link href="'.htmlentities( get_current_url() ).'" rel="self" type="application/rss+xml" />';

	foreach ( $feeds as $f  ){
			echo '<item>
					<title>' . $f->title . '</title>
					<description><![CDATA[' . $f->description . ']]></description>
					<link>' . $f->link . '</link>
					<guid isPermaLink="true">' . $f->link . '</guid>
					<pubDate>' . date( 'D, d M Y H:i:s O' ) . '</pubDate>
				</item>';
	}
	
echo '</channel>
</rss>';
exit;