<?php
defined('ABS') or die;

$category = get_category_by_seoname( get_command(1) );

if ( $category['id'] == 14 ){
	$is_youtube = true;
} else {
	$is_youtube = false;
}

$all_items = load_all_feeds( get_feed_urls($category['id']) );

$max = count($all_items);

// When we end our PHP block, we want to make sure our DOCTYPE is on the top line to make
// sure that the browser snaps into Standards Mode.
$keydata = array( get_command(2) );
$found = false;
foreach($all_items as $key=> $item){
	if ( is_string($item) ){
		$item = get_cached_item($item);
	}
	$titles = array(
			$item->get_title(),
			get_seoname($item->get_title()),
			urldecode( get_seoname($item->get_title()) )
	);
	if( array_intersect($titles, $keydata) ){
		$found = true;
		break;
	}
}
if ( !$found ) {
	header('Location: '.$site_url);
	exit;
}
			
$link = $item->get_link();
$queryString = '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<base href="<?php echo $site_url; ?>" />
	<meta charset="utf-8">
	<meta content="width=device-width, initial-scale=1.0" name="viewport">
	<meta name="description" content="<?php echo $item->get_title(); ?> on RSS WebSite Generator">
	<meta name="keywords" content="<?php echo string_to_cloud($item->get_title()); ?>">
	
	<title><?php echo $item->get_title(); ?> - <?php echo $site_name; ?></title>
	<link href="assets/ico/favicon.png" rel="shortcut icon">
	<link rel="canonical" href="<?php echo get_current_url(); ?>">
	
	<?php if ( !isset($theme_name) ) $theme_name = 'default'; ?>
	<link href="assets/css/themes/<?php echo $theme_name; ?>/bootstrap.min.css" rel="stylesheet">
	<?php if ( get_setting('enable_rtl') == '1' ): ?>
	<link href="assets/css/bootstrap-rtl.min.css" rel="stylesheet">
	<?php endif; ?>
    <link href="assets/css/font-awesome.min.css" rel="stylesheet">
	<link href="assets/css/app.css" rel="stylesheet">
	<link rel="stylesheet" href="/assets/socialcount/socialcount.css">
	<link rel="stylesheet" href="/assets/socialcount/socialcount-with-icons.css">
	
<?php if ( !defined('APP') && get_raw_setting('head_code') ){
	echo get_raw_setting('head_code');
} ?>
</head>
<body id="top" data-spy="scroll" data-target=".subnav" data-offset="80" style="margin-top: 0px;">
	<?php require_once ABS.'/nav.php'; ?>

	<div class="container">
		<?php
			$cicon = '<i class="'.$category['icon'].'"></i>';
		?>
		<div class="page-header">
			<div class="pull-right"> <a class="btn btn-link" href="javascript: history.go(-1)">&larr; Back</a> </div>
			<h1><a href="<?php echo get_site_url( get_seoname($category['name']) ); ?>"><?php echo $cicon; ?> <?php echo ucfirst( get_command(1) ); ?></a></h1>
		</div>
		
	  	<div class="row">
	    	<div class="col-lg-12">
	      		<div class="jumbotron">
		        	<div class="row">
		        		
		        		<img class="media-object thumbnail pull-left" src="<?php echo get_feed_thumbnail($item, $category); ?>" alt="<?php echo $item->get_title(); ?>" />
		        		
		          		<div class="col-lg-4 pull-left">
		            		<h4><?php echo $item->get_date(); ?>
		            			<small><?php echo trim(parse_url($link . $queryString, PHP_URL_HOST), 'www.'); ?></small>
		            		</h4>
		          		</div>
		          		<div class="col-lg-4 pull-right text-right">
		          			<?php $actual_url = ($link . $queryString);
		            			?>
		            		<ul class="socialcount" data-url="<?php echo $actual_url; ?>" data-counts="true">
		              			<li class="facebook"><a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode( get_current_url() ); ?>" title="Share on Facebook"><span class="social-icon icon-facebook"></span><span class="count">Like</span></a></li>
		              			<li class="twitter"><a href="https://twitter.com/intent/tweet?text=<?php echo urlencode( get_current_url() ); ?>" title="Share on Twitter"><span class="social-icon icon-twitter"></span><span class="count">Tweet</span></a></li>
		              			<li class="googleplus"><a href="https://plus.google.com/share?url=<?php echo urlencode( get_current_url() ); ?>" title="Share on Google Plus"><span class="social-icon icon-googleplus"></span><span class="count">+1</span></a></li>
		            		</ul>
		          		</div>
		        	</div>
		        	<h1>
		        	<?php echo $item->get_title(); ?></h1>
		        	<?php
		        		if ( $is_youtube ){
							
							$video_id = '';
							$data = search_in_feed($item->data['child'], 'watch?v');
							foreach ($data as $d){
								//$articlecontent .= isset($d['data']) ? $d['data'] : '';
								//$articlecontent .= get_youtube_player($d['data']);
								$data_url = parse_url( $d['data'] );
								
								if ( isset($data_url['query']) ){
									$vars = explode('&', $data_url['query']);
									foreach ($vars as $vstr){
										list($var, $value) = explode('=', trim($vstr));
										if ( $var == 'v' ){
											$video_id = $value;
										}
									}
								}
								if ( $video_id ) break;
							}
							if ( $video_id ){
								if (!isset($video_width) || empty($video_width)) $video_width = 480;
								if (!isset($video_height) || empty($video_height)) $video_height = 385;
								$articlecontent = get_youtube_player('//www.youtube.com/embed/'.$video_id, $video_width, $video_height);
							}
						}
						if ( !isset($articlecontent) ){
							$articlecontent = '';
						}
						if ( true ){
							$item_desc = $item->get_content();
							$item_desc = preg_replace("/<\/?div[^>]*\>/i", "", $item_desc);
							$item_desc = preg_replace("/([_]{3,})/i", "", $item_desc);
							
							$articlecontent .= $item_desc;
						}
						
					?>
		        	<p><?php echo $articlecontent; ?></p>
				<div class="text-center"><?php display_banner(2); ?></div>
		        	<p><a href="<?php echo $link . $queryString; ?>" data-toggle="preview" class="btn btn-primary btn-lg" rel="nofollow">Read full article</a></p>
		      	</div>

			<div class="text-center"><?php display_banner(1); ?></div>


				<div class="row">
					<div class="container">
						<div id="disqus_thread"></div>
						<script type="text/javascript">
        					/* * * CONFIGURATION VARIABLES: EDIT BEFORE PASTING INTO YOUR WEBPAGE * * */
        					var disqus_shortname = 'rssaggregator'; // required: replace example with your forum shortname

        					/* * * DON'T EDIT BELOW THIS LINE * * */
        					(function() {
            					var dsq = document.createElement('script'); dsq.type = 'text/javascript'; dsq.async = true;
            					dsq.src = '//' + disqus_shortname + '.disqus.com/embed.js';
            					(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(dsq);
        					})();
    					</script>
						<noscript>Please enable JavaScript to view the <a href="http://disqus.com/?ref_noscript">comments powered by Disqus.</a></noscript>
						<a href="http://disqus.com" class="dsq-brlink">comments powered by <span class="logo-disqus">Disqus</span></a>
					</div>
				</div>

	    	</div>
	  	</div>
	  	
	  	<div class="row">
	    	<div class="col-lg-12">
	      		<h2>Tags</h2>
	      		<?php echo string_to_tags($item->get_title()); ?>
	      	</div>
	  	</div>
	</div>
	<?php require_once ABS.'/footer.php'; ?>
	<script type="text/javascript" src="/assets/socialcount/socialcount.js"></script>
</body>
</html>